# "What is Principle Component Analysis (PCA)?"

- toc:true- branch: master
- badges: true
- comments: true
- author: Kshitij Kushwaha
- categories: [ML, Dimension_Reduction]

PCA is a dimension reduction technique widely used for visualising larger dimension data by converting them to two or three dimensions. It is unsupervised statistical technique.
It finds the correlation between the features and converts it into uncorrelated data by transforming them into some other dimesion space whose dimentionality is less than the original data's dimentionality.

Goal of PCA- Represent data in new dimention such that -->
                                1. the data has high variance along these dimetions
                                2. the dimentions are lineary independent (i.e. uncorrelated)
                                3. dimentions are orthogonal
                                
Let's try to understand further with a 2-D data.



```python
#hide
import numpy as np
import random
import matplotlib.pyplot as plt
```


```python
#hide
random.seed(random)
```


```python
#lets create artificial 2-D data
x1 = np.linspace(start = -10, stop = +10, num = 11)
x2 = 2*x1 + x1*random.uniform(a = -1, b = +1)
```


```python
plt.scatter(x1, x2)
plt.title("Dataset")
plt.xlabel('x1')
plt.ylabel('x2')
plt.grid()
plt.show()
```


    
![png](output_5_0.png)
    


Now we have our artificial data set X where 1st column is for x1 and 2nd column for x2. X has 11 examples (no. of data points) and 2 features x1 and x2. 
Clearly $x_2 \sim 3*x_1$ So x1 and x2 are highly correlated.

Lets consider the direction $u$ which coincides with $x_2 \sim 3*x_1$ and we project all the data point on this line.


```python
plt.scatter(x1, x2, label = 'original data points')
plt.scatter(x1, 3*x1, label = 'projected data points', marker = 'x', color = 'r')
plt.plot(x1, 3*x1, label = 'u direction')
plt.xlabel('x1')
plt.ylabel('x2')
plt.grid()
plt.legend()
plt.show()
```


    
![png](output_7_0.png)
    


Now instead of representing your data in x1 and x2 you can just use $u$ to do that. This $u$ direction is called $Principle Component$ as this direction captures the most of the variance in data.

Now your 2-D data is reduced to 1-D data!!

When projecting your original data on $Principle Component$ there is some error as not all the data points lie on this line completely. So the $Principle Component$ is chosen such that this error is minimized.

THIS WAS THE VERY INTUTIVE WAY OF LOOKING AT THE PCA BUT PCA IS MORE THEN THIS SIMPLE ILLUSTRATION.

We will look at the maths behind the PCA and implement it using $scikit-learn$ library in Python.


```python

```
